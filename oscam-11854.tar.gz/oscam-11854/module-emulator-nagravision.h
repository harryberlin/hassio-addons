#ifndef MODULE_EMULATOR_NAGRAVISION_H
#define MODULE_EMULATOR_NAGRAVISION_H

#ifdef WITH_EMU

int8_t nagra2_ecm(uint8_t *ecm, uint8_t *dw);

#endif // WITH_EMU

#endif // MODULE_EMULATOR_NAGRAVISION_H
