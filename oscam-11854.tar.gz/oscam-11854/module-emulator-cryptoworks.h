#ifndef MODULE_EMULATOR_CRYPTOWORKS_H
#define MODULE_EMULATOR_CRYPTOWORKS_H

#ifdef WITH_EMU

int8_t cryptoworks_ecm(uint32_t caid, uint8_t *ecm, uint8_t *cw);

#endif // WITH_EMU

#endif // MODULE_EMULATOR_CRYPTOWORKS_H
