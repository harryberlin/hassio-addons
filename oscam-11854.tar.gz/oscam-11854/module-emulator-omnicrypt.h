#ifndef MODULE_EMULATOR_OMNICRYPT_H
#define MODULE_EMULATOR_OMNICRYPT_H

#ifdef WITH_EMU

int8_t omnicrypt_ecm(uint8_t *ecm, uint8_t *dw);

#endif // WITH_EMU

#endif // MODULE_EMULATOR_OMNICRYPT_H
