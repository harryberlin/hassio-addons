#ifndef ST20_H_
#define ST20_H_

int st20_run(uint8_t* snip, uint32_t snip_len, int addr, uint8_t *data, uint16_t overcryptId);

#endif
